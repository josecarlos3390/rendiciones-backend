import { Module, Global } from '@nestjs/common';
import { ConfigService }  from '@nestjs/config';
import { HanaService }        from './hana.service';
import { SqlServerService }   from './sqlserver.service';
import { DATABASE_SERVICE }   from './interfaces/database.interface';

@Global()
@Module({
  providers: [
    HanaService,
    SqlServerService,
    {
      provide:    DATABASE_SERVICE,
      inject:     [ConfigService, HanaService, SqlServerService],
      useFactory: (
        config:    ConfigService,
        hana:      HanaService,
        sqlServer: SqlServerService,
      ) => {
        const dbType = config.get<string>('app.dbType', 'HANA').toUpperCase();
        return dbType === 'SQLSERVER' ? sqlServer : hana;
      },
    },
  ],
  exports: [DATABASE_SERVICE],
})
export class DatabaseModule {}