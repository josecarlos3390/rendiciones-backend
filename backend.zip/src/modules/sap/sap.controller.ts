import { Controller, Get, Post, Query, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiBearerAuth, ApiTags, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { SapService } from './sap.service';
import { Roles } from '../../auth/decorators/roles.decorator';

@ApiTags('SAP')
@ApiBearerAuth()
@Controller('sap')
export class SapController {
  constructor(private readonly sapService: SapService) {}

  /**
   * GET /api/v1/sap/dimensions
   *
   * Devuelve las dimensiones activas de SAP con sus normas de reparto.
   * El frontend usa DimensionCode para saber en qué campo NR mostrar el dropdown:
   *   DimensionCode 1 → U_NR1 / nr1
   *   DimensionCode 2 → U_NR2 / nr2
   *   ...etc.
   */
  @Get('dimensions')
  @Roles('ADMIN')
  @ApiOperation({ summary: 'Obtiene dimensiones activas con sus normas de reparto desde SAP SL' })
  getDimensions() {
    return this.sapService.getActiveDimensionsWithRules();
  }

  /**
   * POST /api/v1/sap/dimensions/refresh
   * Fuerza la recarga de la caché (útil si cambiaron reglas en SAP)
   */
  @Post('dimensions/refresh')
  @Roles('ADMIN')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Limpia la caché de dimensiones y fuerza recarga desde SAP SL' })
  refreshDimensions() {
    this.sapService.clearCache();
    return this.sapService.getActiveDimensionsWithRules();
  }

  /**
   * GET /api/v1/sap/chart-of-accounts
   * Devuelve cuentas del plan contable SAP:
   * ActiveAccount=tYES, FrozenFor=tNO, AccountLevel=5
   */
  @Get('chart-of-accounts')
  @Roles('ADMIN')
  @ApiOperation({ summary: 'Plan de cuentas SAP (activas, nivel 5, no congeladas)' })
  getChartOfAccounts() {
    return this.sapService.getChartOfAccounts();
  }

  /**
   * GET /api/v1/sap/empleados?car=EMPIEZA&filtro=EL
   *
   * Devuelve BusinessPartners de SAP filtrados según la característica del perfil (U_EMP_CAR):
   *   - EMPIEZA  → CardCode que empieza con el valor de `filtro`  (startswith)
   *   - TERMINA  → CardCode que termina con el valor de `filtro`   (endswith)
   *   - NOTIENE  → lista vacía, sin consultar SAP
   */
  @Get('empleados')
  @ApiOperation({ summary: 'Busca empleados SAP filtrados según la característica del perfil (U_EMP_CAR)' })
  getEmpleados(
    @Query('car')    car:    string,
    @Query('filtro') filtro: string,
  ) {
    return this.sapService.getEmpleados(car ?? 'EMPIEZA', filtro ?? '');
  }

  /**
   * GET /api/v1/sap/proveedores?car=EMPIEZA&filtro=/PR&busqueda=ferreteria
   */
  @Get('proveedores')
  @ApiOperation({ summary: 'Busca proveedores SAP filtrados según configuración del perfil (U_PRO_CAR)' })
  getProveedores(
    @Query('car')      car:      string,
    @Query('filtro')   filtro:   string,
    @Query('busqueda') busqueda: string,
  ) {
    return this.sapService.getProveedores(car ?? 'TODOS', filtro ?? '', busqueda ?? '');
  }

  /**
   * GET /api/v1/sap/cuentas?cueCar=EMPIEZA&cueTexto=/1/2/5&busqueda=caja
   *
   * Devuelve cuentas del plan contable filtradas según la configuración del perfil.
   * Para cueCar=LISTA, pasar las cuentas como JSON en el query param `lista`.
   */
  @Get('cuentas')
  @ApiOperation({ summary: 'Cuentas del plan contable filtradas según configuración del perfil' })
  @ApiQuery({ name: 'cueCar',   required: true,  example: 'EMPIEZA' })
  @ApiQuery({ name: 'cueTexto', required: false, example: '/1/2/5/6/8' })
  @ApiQuery({ name: 'busqueda', required: false, example: 'caja' })
  @ApiQuery({ name: 'lista',    required: false, description: 'JSON de CuentaDto[] para cueCar=LISTA' })
  async getCuentas(
    @Query('cueCar')   cueCar:   string,
    @Query('cueTexto') cueTexto: string,
    @Query('busqueda') busqueda: string,
    @Query('lista')    lista:    string,
  ) {
    let listaCuentas = [];
    if (lista) {
      try { listaCuentas = JSON.parse(lista); } catch { listaCuentas = []; }
    }
    return this.sapService.getCuentasByPerfil(
      { cueCar: cueCar ?? 'TODOS', cueTexto: cueTexto ?? null },
      busqueda ?? '',
      listaCuentas,
    );
  }
}