import { Prov } from '../interfaces/prov.interface';
import { CreateProvDto } from '../dto/create-prov.dto';

export const PROV_REPOSITORY = 'PROV_REPOSITORY';

export interface IProvRepository {
  findAll():    Promise<Prov[]>;
  findByNit(nit: string): Promise<Prov | null>;
  create(dto: CreateProvDto): Promise<Prov>;
  remove(nit: string): Promise<{ affected: number }>;
}