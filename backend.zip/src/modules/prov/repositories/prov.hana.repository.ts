import { Injectable } from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { IDatabaseService, DATABASE_SERVICE } from '../../../database/interfaces/database.interface';
import { IProvRepository } from './prov.repository.interface';
import { Prov } from '../interfaces/prov.interface';
import { CreateProvDto } from '../dto/create-prov.dto';

@Injectable()
export class ProvHanaRepository implements IProvRepository {

  private get schema(): string { return this.config.get<string>('hana.schema'); }
  private get DB(): string     { return `"${this.schema}"."REND_PROV"`; }

  constructor(
    @Inject(DATABASE_SERVICE)
    private readonly db: IDatabaseService,
    private readonly config: ConfigService,
  ) {}

  findAll(): Promise<Prov[]> {
    return this.db.query<Prov>(
      `SELECT "U_NIT", "U_RAZON_SOCIAL" FROM ${this.DB} ORDER BY "U_RAZON_SOCIAL"`,
    );
  }

  async findByNit(nit: string): Promise<Prov | null> {
    const rows = await this.db.query<Prov>(
      `SELECT "U_NIT", "U_RAZON_SOCIAL" FROM ${this.DB} WHERE "U_NIT" = ?`, [nit],
    );
    return rows[0] ?? null;
  }

  async create(dto: CreateProvDto): Promise<Prov> {
    await this.db.execute(
      `INSERT INTO ${this.DB} ("U_NIT", "U_RAZON_SOCIAL") VALUES (?, ?)`,
      [dto.nit, dto.razonSocial],
    );
    return { U_NIT: dto.nit, U_RAZON_SOCIAL: dto.razonSocial };
  }

  async remove(nit: string): Promise<{ affected: number }> {
    const result = await this.db.execute(
      `DELETE FROM ${this.DB} WHERE "U_NIT" = ?`, [nit],
    );
    return { affected: result ?? 1 };
  }
}