import { Injectable, Inject, ConflictException, NotFoundException } from '@nestjs/common';
import { IProvRepository, PROV_REPOSITORY } from './repositories/prov.repository.interface';
import { CreateProvDto } from './dto/create-prov.dto';

@Injectable()
export class ProvService {
  constructor(
    @Inject(PROV_REPOSITORY)
    private readonly repo: IProvRepository,
  ) {}

  findAll() { return this.repo.findAll(); }

  async create(dto: CreateProvDto) {
    const exists = await this.repo.findByNit(dto.nit);
    if (exists) throw new ConflictException(`El NIT "${dto.nit}" ya está registrado`);
    return this.repo.create(dto);
  }

  async remove(nit: string) {
    const exists = await this.repo.findByNit(nit);
    if (!exists) throw new NotFoundException(`NIT "${nit}" no encontrado`);
    return this.repo.remove(nit);
  }
}