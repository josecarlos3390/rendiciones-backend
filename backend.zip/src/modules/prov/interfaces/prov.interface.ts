export interface Prov {
  U_NIT:          string;
  U_RAZON_SOCIAL: string;
}