import { Controller, Get, Post, Delete, Param, Body } from '@nestjs/common';
import { ApiBearerAuth, ApiTags, ApiOperation } from '@nestjs/swagger';
import { ProvService } from './prov.service';
import { CreateProvDto } from './dto/create-prov.dto';

@ApiTags('Proveedores Eventuales')
@ApiBearerAuth()
@Controller('prov')
export class ProvController {
  constructor(private readonly svc: ProvService) {}

  @Get()
  @ApiOperation({ summary: 'Lista proveedores eventuales (REND_PROV)' })
  findAll() { return this.svc.findAll(); }

  @Post()
  @ApiOperation({ summary: 'Registra proveedor eventual' })
  create(@Body() dto: CreateProvDto) { return this.svc.create(dto); }

  @Delete(':nit')
  @ApiOperation({ summary: 'Elimina proveedor eventual por NIT' })
  remove(@Param('nit') nit: string) { return this.svc.remove(nit); }
}